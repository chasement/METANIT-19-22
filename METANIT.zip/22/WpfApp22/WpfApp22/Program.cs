﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System;
using WpfApp22;
public class Program
{
    [STAThread] // атрибут для однопоточного режима WPF
    public static void main()
    {
        // создаем хост приложения
        var host = Host.CreateDefaultBuilder()
            .ConfigureServices(services =>
            {
                services.AddSingleton<App>(); // регистрируем App как синглтон
                services.AddSingleton<MainWindow>(); // регистрируем MainWindow как синглтон
                // регистрируем сервис IDateService с реализацией RuDateService
                services.AddTransient<IDateService, RuDateService>();
            })
            .Build();

        // получаем экземпляр App из контейнера зависимостей
        var app = host.Services.GetService<App>();
        app?.Run(); // запускаем приложение
    }
}

// интерфейс для работы с датой
public interface IDateService
{
    string FormatedDate { get; } // свойство для получения отформатированной даты
}

// реализация IDateService для русской локали
public class RuDateService : IDateService
{
    public string FormatedDate => $"Сегодня: {DateTime.Now.ToString("dd.MM.yyyy")}"; // формат даты "день.месяц.год"
}

// реализация IDateService для английской локали
public class EnDateService : IDateService
{
    public string FormatedDate => $"Today: {DateTime.Now.ToString("MM.dd.yyyy")}"; // формат даты "месяц.день.год"
}