﻿using System.Windows;
using WpfApp22;

public class App : Application
{
    private readonly MainWindow mainWindow; // главное окно приложения

    // конструктор приложения, получает главное окно через внедрение зависимостей
    public App(MainWindow mainWindow)
    {
        this.mainWindow = mainWindow;
    }

    // метод, вызываемый при запуске приложения
    protected override void OnStartup(StartupEventArgs e)
    {
        mainWindow.Show(); // отображаем главное окно на экране
        base.OnStartup(e); // вызываем базовый метод
    }
}