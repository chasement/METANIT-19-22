﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;
using WpfApp20_4;

namespace WpfApp20_4
{
    public class ApplicationViewModel : INotifyPropertyChanged
    {
        private Phone selectedPhone; // выбранный телефон

        // коллекция телефонов
        public ObservableCollection<Phone> Phones { get; set; }

        // команда для добавления нового телефона
        private RelayCommand addCommand;
        public RelayCommand AddCommand
        {
            get
            {
                // если команда не создана, создаем её
                return addCommand ??
                  (addCommand = new RelayCommand(obj =>
                  {
                      Phone phone = new Phone(); // создаем новый телефон
                      Phones.Insert(0, phone); // добавляем его в начало списка
                      SelectedPhone = phone; // делаем его выбранным
                  }));
            }
        }

        // команда для удаления телефона
        private RelayCommand removeCommand;
        public RelayCommand RemoveCommand
        {
            get
            {
                // если команда не создана, создаем её
                return removeCommand ??
                  (removeCommand = new RelayCommand(obj =>
                  {
                      Phone phone = obj as Phone; // получаем объект телефона
                      if (phone != null)
                      {
                          Phones.Remove(phone); // удаляем его из коллекции
                      }
                  },
                 (obj) => Phones.Count > 0)); // команда доступна, если есть телефоны
            }
        }

        // свойство для выбранного телефона
        public Phone SelectedPhone
        {
            get { return selectedPhone; }
            set
            {
                selectedPhone = value;
                OnPropertyChanged("SelectedPhone");
            }
        }

        // конструктор модели представления
        public ApplicationViewModel()
        {
            // инициализируем коллекцию телефонов
            Phones = new ObservableCollection<Phone>
            {
                new Phone { Title="iPhone 7", Company="Apple", Price=56000 },
                new Phone {Title="Galaxy S7 Edge", Company="Samsung", Price =60000 },
                new Phone {Title="Elite x3", Company="HP", Price=56000 },
                new Phone {Title="Mi5S", Company="Xiaomi", Price=35000 }
            };
        }

        // реализация интерфейса INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}