﻿using System;
using System.Windows.Input;

namespace WpfApp20_4
{
    public class RelayCommand : ICommand
    {
        private Action<object> execute; // действие для выполнения команды
        private Func<object, bool> canExecute; // условие выполнения команды

        // событие изменения состояния возможности выполнения команды
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        // конструктор команды
        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            this.execute = execute;
            this.canExecute = canExecute;
        }

        // проверка возможности выполнения команды
        public bool CanExecute(object parameter)
        {
            return this.canExecute == null || this.canExecute(parameter);
        }

        // выполнение команды
        public void Execute(object parameter)
        {
            this.execute(parameter);
        }
    }
}