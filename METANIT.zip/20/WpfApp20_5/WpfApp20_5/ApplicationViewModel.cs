﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace WpfApp20_5
{
    public class ApplicationViewModel : INotifyPropertyChanged
    {
        private Phone selectedPhone; // выбранный телефон

        // коллекция телефонов
        public ObservableCollection<Phone> Phones { get; set; }

        // команда добавления нового телефона
        private RelayCommand addCommand;
        public RelayCommand AddCommand
        {
            get
            {
                // если команда не создана, создаем её
                return addCommand ??
                  (addCommand = new RelayCommand(obj =>
                  {
                      Phone phone = new Phone("", "", 0); // создаем новый телефон
                      Phones.Insert(0, phone); // добавляем его в начало списка
                      SelectedPhone = phone; // делаем его выбранным
                  }));
            }
        }

        // команда удаления телефона
        private RelayCommand removeCommand;
        public RelayCommand RemoveCommand
        {
            get
            {
                // если команда не создана, создаем её
                return removeCommand ??
                  (removeCommand = new RelayCommand(obj =>
                  {
                      Phone phone = obj as Phone; // получаем объект телефона
                      if (phone != null)
                      {
                          Phones.Remove(phone); // удаляем его из коллекции
                      }
                  },
                 (obj) => Phones.Count > 0)); // команда доступна, если есть телефоны
            }
        }

        // команда дублирования телефона
        private RelayCommand doubleCommand;
        public RelayCommand DoubleCommand
        {
            get
            {
                // если команда не создана, создаем её
                return doubleCommand ??
                    (doubleCommand = new RelayCommand(obj =>
                    {
                        Phone phone = obj as Phone; // получаем объект телефона
                        if (phone != null)
                        {
                            // создаем копию телефона и добавляем её в начало списка
                            Phone phoneCopy = new Phone(phone.Title, phone.Company, phone.Price);
                            Phones.Insert(0, phoneCopy);
                        }
                    }));
            }
        }

        // свойство для выбранного телефона
        public Phone SelectedPhone
        {
            get { return selectedPhone; }
            set
            {
                selectedPhone = value;
                OnPropertyChanged("SelectedPhone");
            }
        }

        // конструктор модели представления
        public ApplicationViewModel()
        {
            // инициализируем коллекцию телефонов
            Phones = new ObservableCollection<Phone>
            {
                new Phone("iPhone 7", "Apple", 56000),
                new Phone("Galaxy S7 Edge", "Samsung", 60000),
                new Phone("Elite x3", "HP", 56000),
                new Phone("Mi5S", "Xiaomi", 35000)
            };
        }

        // реализация интерфейса INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }

    // класс для реализации команды
    public class RelayCommand : ICommand
    {
        private Action<object> execute; // действие для выполнения команды
        private Func<object, bool> canExecute; // условие выполнения команды

        // событие изменения состояния возможности выполнения команды
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        // конструктор команды
        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            this.execute = execute;
            this.canExecute = canExecute;
        }

        // проверка возможности выполнения команды
        public bool CanExecute(object parameter)
        {
            return canExecute == null || canExecute(parameter);
        }

        // выполнение команды
        public void Execute(object parameter)
        {
            execute(parameter);
        }
    }
}