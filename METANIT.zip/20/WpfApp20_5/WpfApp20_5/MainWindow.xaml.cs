﻿using System;
using System.Windows;
using WpfApp20_5;

namespace MVVM
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            DataContext = new ApplicationViewModel();
        }

        private void InitializeComponent()
        {
            throw new NotImplementedException();
        }
    }
}