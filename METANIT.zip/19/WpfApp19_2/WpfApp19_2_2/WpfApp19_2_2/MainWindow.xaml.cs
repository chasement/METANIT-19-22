﻿using System.Windows;
using System.Windows.Media;

namespace WpfApp19_2_2
{
    /// <summary>
    /// Логика взаимодействия для TaskWindow.xaml
    /// </summary>
    public partial class TaskWindow : Window
    {
        // свойство для хранения данных (viewmodel)
        public string ViewModel { get; set; }

        public TaskWindow()
        {
            InitializeComponent();
        }

        // метод для отображения viewmodel в messagebox
        public void ShowViewModel()
        {
            MessageBox.Show(ViewModel);
        }
    }

    // дополнительный частичный класс для taskwindow
    public partial class TaskWindow : Window
    {
        // метод для изменения фона окна-владельца
        public void ChageOwnerBackground()
        {
            this.Owner.Background = new SolidColorBrush(Colors.Red);
        }
    }
}