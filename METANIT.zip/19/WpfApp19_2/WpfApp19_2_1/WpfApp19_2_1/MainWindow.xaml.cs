﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp19_2_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // обработчик нажатия на кнопку
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // создание нового окна taskwindow
            TaskWindow taskWindow = new TaskWindow();
            taskWindow.Owner = this; // установка текущего окна как владельца
            taskWindow.Show(); // отображение окна

            // перебор всех окон, принадлежащих текущему окну
            foreach (Window window in this.OwnedWindows)
            {
                // изменение фона всех окон на красный
                window.Background = new SolidColorBrush(Colors.Red);

                // если окно является taskwindow, изменяем его заголовок
                if (window is TaskWindow)
                    window.Title = "Новый заголовок!";
            }
        }
    }
}