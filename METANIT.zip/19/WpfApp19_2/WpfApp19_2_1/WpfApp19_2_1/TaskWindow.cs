﻿using System;

namespace WpfApp19_2_1
{
    internal class TaskWindow
    {
        public MainWindow Owner { get; internal set; }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}