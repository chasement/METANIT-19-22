﻿using System;
using System.Windows;
using System.Windows.Media;
using System.IO;

namespace WpfApp19_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // путь к файлу для логирования
        string path = "log.txt";

        public MainWindow()
        {
            InitializeComponent();

            // подписка на события окна
            this.Loaded += MainWindow_Loaded; // событие загрузки окна
            this.Closing += MainWindow_Closing; // событие закрытия окна (перед закрытием)
            this.Closed += MainWindow_Closed; // событие закрытия окна (после закрытия)
        }

        // обработчик события загрузки окна
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            Log("Loaded"); // запись в лог о загрузке окна
        }

        // обработчик события закрытия окна (перед закрытием)
        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Log("Closing"); // запись в лог о начале закрытия окна
        }

        // обработчик события закрытия окна (после закрытия)
        private void MainWindow_Closed(object sender, EventArgs e)
        {
            Log("Closed"); // запись в лог о завершении закрытия окна
        }

        // метод для записи сообщений в лог
        private void Log(string eventName)
        {
            // открытие файла для записи (режим добавления)
            using (StreamWriter logger = new StreamWriter(path, true))
            {
                // запись текущего времени и названия события
                logger.WriteLine(DateTime.Now.ToLongTimeString() + " - " + eventName);
            }
        }
    }
}