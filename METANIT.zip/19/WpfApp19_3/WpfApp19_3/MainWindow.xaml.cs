﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp19_3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // обработчик нажатия на кнопку "логин"
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            // создание окна для ввода пароля
            PasswordWindow passwordWindow = new PasswordWindow();

            // отображение окна как диалогового и проверка результата
            if (passwordWindow.ShowDialog() == true)
            {
                // проверка введенного пароля
                if (passwordWindow.Password == "12345678")
                    MessageBox.Show("авторизация пройдена");
                else
                    MessageBox.Show("неверный пароль");
            }
            else
            {
                // если диалог отменен
                MessageBox.Show("авторизация не пройдена");
            }
        }
    }
}