﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp19_3
{
    /// <summary>
    /// Логика взаимодействия для PasswordWindow.xaml
    /// </summary>
    public partial class PasswordWindow : Window
    {
        public PasswordWindow()
        {
            InitializeComponent();
        }

        // обработчик нажатия на кнопку "ok"
        private void Accept_Click(object sender, RoutedEventArgs e)
        {
            // установка результата диалога как true (успешное завершение)
            this.DialogResult = true;
        }

        // свойство для получения введенного пароля
        public string Password
        {
            get { return passwordBox.Text; }
        }
    }
}